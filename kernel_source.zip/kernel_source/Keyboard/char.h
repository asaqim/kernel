#ifndef CHAR_H
#define CHAR_H

#include "types.h"
#include "keyboard.h"


extern char get_ascii_char(uint8);

#endif


